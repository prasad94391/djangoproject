from django.apps import AppConfig


class ElenConfig(AppConfig):
    name = 'Elen'
