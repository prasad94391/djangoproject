from django.db import models


class Student(models.Model):
    idno=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=50)
    branch=models.CharField(max_length=20)
    course=models.CharField(max_length=20)
    email=models.EmailField(max_length=20)
    contact_no=models.IntegerField()
    gender=models.CharField(max_length=10)


class Faculty(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=100)
    contact_no=models.IntegerField()
    qualification=models.CharField(max_length=50)
    gender=models.CharField(max_length=20)


class Bookinfo(models.Model):
    book_no=models.IntegerField()
    boon_name=models.CharField(max_length=20)

