from django.contrib import admin
from.models import Student
from.models import Faculty
from.models import Bookinfo

admin.site.register(Student)
admin.site.register(Faculty)
admin.site.register(Bookinfo)

